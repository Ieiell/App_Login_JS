import {useState} from 'react';
import AS_Cursos from '@react-native-async-storage/async-storage’;
import AS_Alunos from '@react-native-async-storage/async-storage';
import { StyleSheet, Text, View } from 'react-native';

export default function App(){
  const[curso, setCurso] = useState('');
  const[matricula, setMatricula] = useState('');
  const[nome, setNome]= useState('');
  const[email, setEmail] = useState('');

  async function gravarCurso(chave,valor){
    AS_Cursos.setItem(chave,valor);    
  }

  async function buscarCurso(chave){
    const valor = await AS_Cursos.getItem(chave);
    setCurso(valor);
  }

  async function removerCurso(chave){AS_Cursos.removerItem(chave)
  }
  async function limparCursos(){
    AS_Cursos.clear();
  }

  async function gravarAluno(chave,inputMatr,inputNome,inputEmail){
    const aluno ={matricula:inputMatr,
    nome:inputNome,
    email:inputEmail};
  
  const alunoJSON= json.stringfy(aluno);
  await AS_Alunos.setItem(chave,alunoJSON)
  }

  async function buscarAluno(chave){
    const alunoJSON = await AS_Alunos.getItem(chave);
    setMatricula(JSON.parse(alunoJSON).matricula);
    setNome(JSON.parse(alunoJSON).nome);
    setEmail(JSON.parse(alunoJSON).email);
  }

  gravarCurso('1','Sistema de informação');
  gravarCurso('2','ADM. de banco de dados');
  gravarCurso('3','Analise de Sistemas'),

  buscarCurso('1')

  gravarAluno('1','61568686315','Emmanuel Torquato','Emmanuel@gmail.com');
  gravarAluno('2','76753737533','Arthur Silva','Arthur@gmail.com');
  gravarAluno('3','89675353785','João Bosco','joão@gmail.com');
  gravarAluno('4','97537845388','Kauan Gimenes ','kauan@gmail.com');
  gravarAluno('5','34846753453','Larissa Neves ','larissa@gmail.com');

  buscarAluno('1')

return(
  <View style={styles.container}>
  <Text>Curso de TI</Text>
  <Text>Matricula:{matricula}</Text>
  <Text>Email:{email}</Text>
  <Text>Curso:{curso}</Text>
  </View>
);

const styles = StyleSheet.create({container:{
  flex:1,
  backgroundColor: '#fff',
  alignItems ' center',
  justifyContent: 'center',

},
});





  

}